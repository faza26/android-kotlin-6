package com.aufazaki.kopikenangan

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.aufazaki.kopikenangan.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)



        supportActionBar?.hide()

        /* Inisialisasi Variabel */
        binding= ActivityMainBinding.inflate(layoutInflater)
        val nama = binding.etNama
        val pesanan = binding.etPesanan
        val btnPesan = binding.btnPesan


       /* Harga KopiMantan*/
        var kopiMantan = 15000


        /* Action */
        btnPesan.setOnClickListener { jumlahPesanan(nama.text.toString(), pesanan.text.toString(), kopiMantan) }

    }

    private fun jumlahPesanan(nama: String, pesanan: String , kopiMantan: Int){
        if (nama.isEmpty()) {
            binding.etNama.error = "Input Tidak Valid"
        } else if(pesanan.isEmpty()) {
            binding.etPesanan.error="Jumlah Pesanan Tidak Valid"
        } else {

            var total = pesanan.toInt()*kopiMantan
            binding.tvTotal.text=total.toString()
            binding.tvNama.text= nama

        }
    }
}







